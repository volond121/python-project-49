### Hexlet tests and linter status:
[![Actions Status](https://github.com/volond121/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/volond121/python-project-49/actions)

<a href="https://codeclimate.com/github/volond121/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/e65e05d2484a6468ccad/maintainability" /></a>

<p> <a href="https://asciinema.org/a/wq0LFr8m8Kxd4nZxE3UzsvuDz"> Recording "brain-games" on asciinema.org </a></p>

<p> <a href="https://asciinema.org/a/ATWdKVLWTHk7Ke4is7O6EzVlQ"> Recording "brain-calc" on asciinema.org </a></p>

<p> <a href="https://asciinema.org/a/eicEySXF5s8m8qA8Ss6ix9iCg"> Recording "brain-gcd" on asciinema.org </a></p>
