### Hexlet tests and linter status:
[![Actions Status](https://github.com/volond121/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/volond121/python-project-49/actions)

<a href="https://codeclimate.com/github/volond121/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/e65e05d2484a6468ccad/maintainability" /></a>

<p> <a href="https://asciinema.org/a/cSKhzGkAL3YqvXPnewD6ph4gU"> Recording "brain-games" on asciinema.org </a></p>