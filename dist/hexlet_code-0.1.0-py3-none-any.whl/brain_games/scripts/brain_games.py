#!/usr/bin/env python3

from brain_games.cli import question_and_cheer


def main():
    question_and_cheer()
    

if __name__ == '__main__':
    main()
